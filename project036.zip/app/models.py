from app import db
from datetime import datetime

class ExamQuestions(db.Model):
    __tablename__='exam_questions'

    id = db.Column(db.Integer, primary_key=True)
    etype = db.Column(db.String(50))
    recorder = db.Column(db.String(50))
    question  = db.Column(db.String(2000))
    answer  = db.Column(db.String(100))
    explanation  = db.Column(db.String(500))

    keyword1 = db.Column(db.String(100))
    keyword2 = db.Column(db.String(100))
    keyword3 = db.Column(db.String(100))
    keyword4 = db.Column(db.String(100))

    source = db.Column(db.String(50))
    knowledge = db.Column(db.String(50))
    difficulty = db.Column(db.String(50))

    option1  = db.Column(db.String(500))
    option2  = db.Column(db.String(500))
    option3  = db.Column(db.String(500))
    option4  = db.Column(db.String(500))

    def to_json(self):
        result = {
            'id' : self.id,
            'answer' : self.answer,
            'difficulty' : self.difficulty,
            'etype' : self.etype,
            'explanation' : self.explanation,
            'keyword1' : self.keyword1,
            'keyword2' : self.keyword2,
            'keyword3' : self.keyword3,
            'keyword4' : self.keyword4,
            'knowledge' : self.knowledge,
            'option1' : self.option1,
            'option2' : self.option2,
            'option3' : self.option3,
            'option4' : self.option4,
            'question' : self.question,
            'recorder' : self.recorder,
            'source' : self.source
        }
        return result


    def __repr__(self):
        return "<ExamQuestions: {}>".format(self.etype)

