from flask import Blueprint

exams = Blueprint('exams', __name__)

from . import views
