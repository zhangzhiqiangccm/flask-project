# encoding: utf-8
from flask import Flask, session, redirect, url_for, request, render_template, flash, jsonify
from .. import db
from ..models import ExamQuestions
from . import exams
from sqlalchemy import or_, and_
import random

dictsearch = {
    'singlenum1':['单选题','简单'],
    'singlenum2':['单选题','中等'],
    'singlenum3':['单选题','较难'],
    'mulnum1':['多选题','简单'],
    'mulnum2':['多选题','中等'],
    'mulnum3':['多选题','较难'],
    'judgenum1':['判断题','简单'],
    'judgenum2':['判断题','中等'],
    'judgenum3':['判断题','较难'],
    'optnum1':['操作题','简单'],
    'optnum2':['操作题','中等'],
    'optnum3':['操作题','较难'],
}


@exams.route('/', defaults={'page':1})
@exams.route('/page/<int:page>')
def index(page):
    try:
        if not 'username' in session:
            flash('尚未登录或者会话已过期，请先登录系统!', 'danger')
            return redirect("/")
        paginate = None
        records = ExamQuestions.query
        if records:
            if request.args.get('etype'):
                etype = request.args.get('etype')
                records = records.filter_by(etype=etype)
            if request.args.get('difficulty'):
                difficulty = request.args.get('difficulty')
                records = records.filter_by(difficulty=difficulty)
            if request.args.get('qkey'):
                qkey = request.args.get('qkey')
                records = records.filter(or_(
                                            ExamQuestions.keyword1.like('%{}%'.format(qkey)),
                                            ExamQuestions.keyword2.like('%{}%'.format(qkey)),
                                            ExamQuestions.keyword3.like('%{}%'.format(qkey)),
                                            ExamQuestions.keyword4.like('%{}%'.format(qkey))
                ))              
        paginate = records.paginate(page, 5)
        print(len(paginate.items))
        return render_template('index.html', results = paginate.items, paginate=paginate)
    except Exception as e:
        print(e)
        flash('有错误发生','danger')
        return render_template('index.html', results = [])

@exams.route('/detail/<id>')
def detail(id):
    try:
        blog = ExamQuestions.query.get_or_404(id)
        db.session.commit()
        return render_template('examdetail.html', result = blog)
    except Exception as e:
        print(e)
        flash('有错误发生')
        return render_template('index.html', results = [])

#增删改查
@exams.route('/add', methods=['GET','POST'])
def add():
    if request.method == 'POST':
        try: 
            etype = request.form.get('etype')
            recorder = request.form.get('recorder')
            question = request.form.get('question')
            answer = request.form.get('answer')
            explanation = request.form.get('explanation')

            keyword1 = request.form.get('keyword1')
            keyword2 = request.form.get('keyword2')
            keyword3 = request.form.get('keyword3')
            keyword4 = request.form.get('keyword4')

            source = request.form.get('source')
            knowledge = request.form.get('knowledge')
            difficulty = request.form.get('difficulty')

            option1 = request.form.get('option1')
            option2 = request.form.get('option2')
            option3 = request.form.get('option3')
            option4 = request.form.get('option4')
        
            examqst = ExamQuestions.query.filter_by(question=question).first()
            if examqst:
                flash('同名题目 {} 已经存在！'.format(question),'danger')
                return redirect(url_for('exams.index'))
            else:
                examqst = ExamQuestions(etype = etype,
                                    recorder = recorder,
                                    question = question,
                                    answer = answer,
                                    explanation = explanation,
                                    keyword1 = keyword1,
                                    keyword2 = keyword2,
                                    keyword3 = keyword3,
                                    keyword4 = keyword4,
                                    source = source,
                                    knowledge = knowledge,
                                    difficulty = difficulty,
                                    option1 = option1,
                                    option2 = option2,
                                    option3 = option3,
                                    option4 = option4)
                db.session.add(examqst)
                db.session.commit()
                flash('试题创建成功!','success')
                return redirect(url_for('exams.index'))
        except Exception as e:
            print('exception - {}'.format(str(e)))
            flash('有异常发生，请稍后再试!','danger')
            return redirect(url_for('exams.index'))
    else:
        return render_template('exams.html', url="/exams/add", result=[])

@exams.route('/delete/<id>', methods=['GET','POST'])
def delete(id):
    try:
        exam = ExamQuestions.query.get_or_404(id)
        db.session.delete(exam)
        db.session.commit()
        flash('删除成功!','success')
        return redirect(url_for('exams.index'))
    except Exception as e:
        print('exception - {}'.format(str(e)))
        flash('有异常发生，请稍后再试!','danger')
        return redirect(url_for('exams.index'))
    

@exams.route('/edit/<id>', methods=['GET','POST'])
def edit(id):
    exam = ExamQuestions.query.get_or_404(id)
    if request.method == 'POST':
        try: 
            exam.etype = request.form.get('etype')
            exam.recorder = request.form.get('recorder')
            exam.question = request.form.get('question')
            exam.answer = request.form.get('answer')
            exam.explanation = request.form.get('explanation')
            exam.keyword1 = request.form.get('keyword1')
            exam.keyword2 = request.form.get('keyword2')
            exam.keyword3 = request.form.get('keyword3')
            exam.keyword4 = request.form.get('keyword4')
            exam.source = request.form.get('source')
            exam.knowledge = request.form.get('knowledge')
            exam.difficulty = request.form.get('difficulty')
            exam.option1 = request.form.get('option1')
            exam.option2 = request.form.get('option2')
            exam.option3 = request.form.get('option3')
            exam.option4 = request.form.get('option4')
            db.session.commit()

            flash('更改成功!','success')
            return redirect(url_for('exams.index'))
        except Exception as e:
            print('exception - {}'.format(str(e)))
            flash('有异常发生，请稍后再试!','danger')
            return redirect(url_for('exams.index'))
    else:
        return exam.to_json()

@exams.route('/generate', defaults={'page':1}, methods=['GET','POST'])
@exams.route('/generate/page/<int:page>')
def generate(page):
    if request.method == 'POST':
        try:
            paginate = None
            records = ExamQuestions.query
            filterresults = []
            filternums = ['singlenum1', 'singlenum2', 'singlenum3', 'mulnum1', 'mulnum2', 'mulnum3', 'judgenum1', 'judgenum2', 'judgenum3', 'optnum1', 'optnum2', 'optnum3']
            if records:
                for filternum in filternums:
                    if request.form.get(filternum):
                        filterquery = records.filter(and_(
                            ExamQuestions.etype == dictsearch[filternum][0], 
                            ExamQuestions.difficulty == dictsearch[filternum][1])
                            ).limit(request.form.get(filternum))
                        filterresults.append(filterquery)
                if filterresults:
                    for i in range(1,len(filterresults)):
                        filterresults[0] = filterresults[0].union(filterresults[i])
                    records = filterresults[0]
                    session['recordids'] = [record.id for record in records]
            print(records.count())
            paginate = records.paginate(page, 5)
            
            return render_template('generateexam.html', results = paginate.items, paginate=paginate)
        except Exception as e:
            print(e)
            flash('有错误发生','danger')
            return render_template('generateexam.html', results = [])
    else:
        session.pop('recordids', None)
        return render_template('generateexam.html', results = [])

@exams.route('/download',methods=['GET'])
def download():
    # todo lit
    pass


# rand = random.randrange(0, session.query(Table).count()) 
# row = session.query(Table)[rand]