from flask import Flask, redirect, url_for
from config import config
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy(use_native_unicode='utf8')

def create_app(config_name):
    app = Flask(__name__)
    try:
        app.config.from_object(config[config_name])
        config[config_name].init_app(app)
    except Exception as e:
        print('config {}'.format(app.config))
        print(e)
   
    bootstrap=Bootstrap(app)
    db.init_app(app)

    from .users import users as users_blueprint
    app.register_blueprint(users_blueprint, url_prefix='/')

    from .exams import exams as exams_blueprint
    app.register_blueprint(exams_blueprint, url_prefix='/exam')


    return app
