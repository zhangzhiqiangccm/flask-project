function Edit(elm) {
    var id = $(elm).attr('data-id');
    $.ajax({
        url: '/exam/edit/' + id,
        type: 'GET',
        success: function(data) {
            console.log(data);
            $('#id').val(data['id']);
            $('#answer').val(data['answer']);
            $('#difficulty').val(data['difficulty']);
            $('#etype').val(data['etype']);
            $('#explanation').val(data['explanation']);
            $('#keyword1').val(data['keyword1']);
            $('#keyword2').val(data['keyword2']);
            $('#keyword3').val(data['keyword3']);
            $('#keyword4').val(data['keyword4']);
            $('#knowledge').val(data['knowledge']);
            $('#option1').val(data['option1']);
            $('#option2').val(data['option2']);
            $('#option3').val(data['option3']);
            $('#option4').val(data['option4']);
            $('#question').val(data['question']);
            $('#recorder').val(data['recorder']);
            $('#source').val(data['source']);

            $("#editform").attr("action", "/exam/edit/" + id );
            $('#editexam').modal();
        },
        error: function(error) {
            console.log(error);
        }
    });
}