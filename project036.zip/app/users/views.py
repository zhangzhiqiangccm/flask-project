# encoding: utf-8
from flask import Flask, session, redirect, url_for, request, render_template, flash
from . import users

@users.route('/')
def index():
    return render_template('login.html')

@users.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username',None)
        password = request.form.get('password',None)
        try:
            if username and password:
                if username == 'aaa' and password == '111':
                    session['username'] = username
                    flash('你好 {}, 欢迎来到在线题库系统!'.format(username),'success')
                    return redirect(url_for('exams.index'))
                else:
                    flash('用户名和密码不匹配，请检查后重试!', 'danger')
                    return redirect(url_for('users.index'))
            else:
                flash('用户名和密码都不能为空，请检查后重试!', 'danger')
                return redirect(url_for('users.index'))
        except Exception as e:
            print('exception - {}'.format(str(e)))
            flash('登录异常，请稍后再试!','danger')
            return redirect(url_for('users.index'))
    else:
        return redirect(url_for('users.index'))


@users.route('/logout', methods=['GET'])
def logout():
    session.pop('username', None)
    # flash('欢迎下次再来', 'success')
    return redirect(url_for('users.login'))