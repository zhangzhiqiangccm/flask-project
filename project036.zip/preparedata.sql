INSERT INTO exam_questions(etype, recorder, question, answer, explanation, keyword1, keyword2, keyword3, keyword4, source, knowledge, difficulty, option1, option2, option3, option4)
  VALUES
  ('单选题','赵一','在SQL查询语句中2，下列说法正确的是( )。'	,'A', '这是答案解析一','1.2','完整性规则',	'关系模型	','外键','	教材','熟练
  ','中等','UPDATE Teacher SET 姓名=姓名 & "优秀"','UPDATE SET 姓名=姓名 & "优秀" FROM Teacher',	'INSERT Teacher SET 姓名=姓名 & "优秀"'
  ,'INSERT SET 姓名=姓名 & "优秀" FROM Teachr'),
    ('单选题','赵一','在SQL查询语句中2，下列说法正确的是( )。'	,'A', '这是答案解析一','1.2','完整性规则',	'关系模型	','外键','	教材','熟练
  ','简单','UPDATE Teacher SET 姓名=姓名 & "优秀"','UPDATE SET 姓名=姓名 & "优秀" FROM Teacher',	'INSERT Teacher SET 姓名=姓名 & "优秀"'
  ,'INSERT SET 姓名=姓名 & "优秀" FROM Teachr'),
      ('单选题','赵一','在SQL查询语句中3，下列说法正确的是( )。'	,'A', '这是答案解析一','1.2','完整性规则',	'关系模型	','外键','	教材','熟练
  ','中等','UPDATE Teacher SET 姓名=姓名 & "优秀"','UPDATE SET 姓名=姓名 & "优秀" FROM Teacher',	'INSERT Teacher SET 姓名=姓名 & "优秀"'
  ,'INSERT SET 姓名=姓名 & "优秀" FROM Teachr'),
      ('单选题','赵一','在SQL查询语句中4，下列说法正确的是( )。'	,'A', '这是答案解析一','1.2','完整性规则',	'关系模型	','外键','	教材','熟练
  ','简单','UPDATE Teacher SET 姓名=姓名 & "优秀"','UPDATE SET 姓名=姓名 & "优秀" FROM Teacher',	'INSERT Teacher SET 姓名=姓名 & "优秀"'
  ,'INSERT SET 姓名=姓名 & "优秀" FROM Teachr'),
      ('单选题','赵一','在SQL查询语句中5，下列说法正确的是( )。'	,'A', '这是答案解析一','1.2','完整性规则',	'关系模型	','外键','	教材','熟练
  ','中等','UPDATE Teacher SET 姓名=姓名 & "优秀"','UPDATE SET 姓名=姓名 & "优秀" FROM Teacher',	'INSERT Teacher SET 姓名=姓名 & "优秀"'
  ,'INSERT SET 姓名=姓名 & "优秀" FROM Teachr'),
      ('单选题','赵一','在SQL查询语句中6，下列说法正确的是( )。'	,'A', '这是答案解析一','1.2','完整性规则',	'关系模型	','外键','	教材','熟练
  ','较难','UPDATE Teacher SET 姓名=姓名 & "优秀"','UPDATE SET 姓名=姓名 & "优秀" FROM Teacher',	'INSERT Teacher SET 姓名=姓名 & "优秀"'
  ,'INSERT SET 姓名=姓名 & "优秀" FROM Teachr');
  