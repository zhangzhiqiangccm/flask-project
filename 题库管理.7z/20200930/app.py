from flask import Flask, render_template, request, jsonify, session
import pymysql

app = Flask(__name__)
app.config['DEBUG'] = True
app.config['SECRET_KEY'] = '123456'

# 封装SQL语句函数
def func(sql, m='r'):
    py = pymysql.connect('127.0.0.1', 'root', 'root123', 'iot', charset="utf8", cursorclass=pymysql.cursors.DictCursor)
    cursor = py.cursor()
    try:
        cursor.execute(sql)
        if m == 'r':
            data = cursor.fetchall()
        elif m == 'w':
            py.commit()
            data = cursor.rowcount
    except:
        data = False
        py.rollback()
    py.close()
    return data


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route('/jsondata', methods=['POST', 'GET'])
def infos():
    data = []
    if request.method == 'POST':
        print('post')
    if request.method == 'GET':
        info = request.values
        qtype = info.get('qtype')
        qlevel = info.get('qlevel')
        qkey = info.get('qkey')

        sql = "SELECT Id,QType,QCreater,QContent,QAnswer,\
        QAnswerRemark,Qkey1,Qkey2,Qkey3,Qkey4,\
        Qrenzhih,Qsource,Qpoint,Qlevel,\
        QA,QB,QC,QD\
        FROM question where 1=1 "
        if qtype != '':
            sql = sql + " and QType='" + qtype + "'"
        if qlevel != '':
            sql = sql + " and Qlevel='" + qlevel + "'"
        if qkey != '':
            sql = sql + " and (Qkey1 like '%" + qkey + "%'"
            sql = sql + " or Qkey2 like '%" + qkey + "%'"
            sql = sql + " or Qkey3 like '%" + qkey + "%'"
            sql = sql + " or Qkey4 like '%" + qkey + "%')"
        sql = sql + " order by Id asc"
        data = list(func(sql))
        limit = info.get('limit', 10)  # 每页显示的条数
        offset = info.get('offset', 0)  # 分片数，(页码-1)*limit，它表示一段数据的起点
    return jsonify({'total': len(data), 'rows': data[int(offset):(int(offset) + int(limit))]})


@app.route('/savedata', methods=["POST"])
def savedata():
    Id = request.form['Id']
    QType = request.form['QType']
    QCreater = request.form['QCreater']
    QContent = request.form['QContent']
    QAnswer = request.form['QAnswer']
    QAnswerRemark = request.form['QAnswerRemark']
    Qkey1 = request.form['Qkey1']
    Qkey2 = request.form['Qkey2']
    Qkey3 = request.form['Qkey3']
    Qkey4 = request.form['Qkey4']
    Qrenzhih = request.form['Qrenzhih']
    Qsource = request.form['Qsource']
    Qpoint = request.form['Qpoint']
    Qlevel = request.form['Qlevel']
    QA = request.form['QA']
    QB = request.form['QB']
    QC = request.form['QC']
    QD = request.form['QD']
    data = dict(request.form)
    sql = "replace into question values ('{Id}','{QType}','{QCreater}','{QContent}','{QAnswer}','{QAnswerRemark}','{Qkey1}','{Qkey2}','{Qkey3}','{Qkey4}','{Qrenzhih}','{Qsource}','{Qpoint}','{Qlevel}','{QA}','{QB}','{QC}','{QD}')".format(**data)
    res = func(sql, m='w')
    if res:
        return jsonify("true")
    else:
        return jsonify("false")

@app.route('/deldata', methods=["POST"])
def deldata():
    Id = request.form['Id']
    data = dict(request.form)
    sql = "delete from question where Id={Id}".format(**data)
    res = func(sql, m='w')
    if res:
        return jsonify("true")
    else:
        return jsonify("false")

if __name__ == '__main__':
    app.run()
